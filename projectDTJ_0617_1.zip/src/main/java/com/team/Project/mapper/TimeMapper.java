package com.team.Project.mapper;

public interface TimeMapper {
	
	public String getTime();
}
