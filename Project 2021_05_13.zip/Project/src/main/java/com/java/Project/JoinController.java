package com.java.Project;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */

@Controller
public class JoinController {
	
	private static final Logger logger = LoggerFactory.getLogger(JoinController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping("member/join1/join_01")
	public String join01(Model model) {
		logger.info("popup join_01 page");
		model.addAttribute("message","이용약관");
		return "member/join1/join_01";
	}
	
	@RequestMapping("member/join1/join_02")
	public String join02(Model model) {
		logger.info("popup join_02 page");
		model.addAttribute("message","개인정보");
		return "member/join1/join_02";
	}
		
}
