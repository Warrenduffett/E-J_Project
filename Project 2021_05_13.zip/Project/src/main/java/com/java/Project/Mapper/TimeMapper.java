package com.java.Project.Mapper;

public interface TimeMapper {
	
	public String getTime();
}
